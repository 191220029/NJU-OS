#include "types.h"
#include "utils.h"
#include "lib.h"

union DirEntry {
	uint8_t byte[128];
	struct {
		int32_t inode;
		char name[64];
	};
};

typedef union DirEntry DirEntry;



int ls(char *destFilePath) {
	printf("ls %s\n", destFilePath);
	int i = 0;
	int fd = 0;
	int ret = 0;
	DirEntry *dirEntry = 0;
	uint8_t buffer[512 * 2];
	fd = open(destFilePath, O_READ | O_DIRECTORY);
	if (fd == -1)
		return -1;
	ret = read(fd, buffer, 512 * 2);
	while (ret != 0) {
		// TODO: Complete 'ls'.
		dirEntry = (DirEntry *)buffer;
		for(i = 0; i < (512 * 2) / sizeof(DirEntry); i++){
			if(dirEntry[i].inode)
				printf("%s ", dirEntry[i].name);
		}
		ret = read(fd, buffer, 512 * 2);
	}
	printf("\n");
	close(fd);
	return 0;
}


int cat(char *destFilePath) {
	printf("cat %s\n", destFilePath);
	int fd = 0;
	int ret = 0;
	uint8_t buffer[512 * 2];
	fd = open(destFilePath, O_READ);
	if (fd == -1)
		return -1;
	ret = read(fd, buffer, 512 * 2);
	while (ret != 0) {
		// TODO: COmplete 'cat'
		printf("%s", buffer);
		ret = read(fd, buffer, 512 * 2);
	}
	close(fd);
	return 0;
}

int shell_cat(char* cur_path, char* destFile){
	if(cat(destFile) == -1){
		int length = stringLen(destFile);
		int size = 0;
		stringChrR(destFile, ' ', &size);
		char destFilepPath[1024];
		stringCpy(cur_path, destFilepPath, stringLen(cur_path));
		destFilepPath[stringLen(destFilepPath)] = '/';
		stringCpy(destFile + size + 1, destFilepPath + stringLen(cur_path) + 1, length - size - 1);
		int ret = cat(destFilepPath);
		if(ret == -1)
			printf("cat : %s: No such file or directory\n", destFile);
	}
	return 0;
}

int cd(char* cur_path, char* order){
	int i;
	int ret;
	char temp_path[1024];
	char dst_path[1024];
    dst_path[0] = '/';
    stringCpy(cur_path, temp_path, 1024);
    int point_flag = 0;
    for(i=0; i < stringLen(order); i ++)  {
        if(order[i] == ' ')
            point_flag=1;
        else if(order[i] !=' ' && point_flag == 1)   {
            point_flag=i;
            break;
         }
    }
    stringCpy(order + point_flag, dst_path, 1024 - point_flag);

    int cur_index = stringLen(cur_path);
    if(cur_path[cur_index - 1] == '/')    {
        cur_path[cur_index] = 0;
        cur_index--;
    }

	//printf("cur_path = %s\n", cur_path);
	//printf("cur_index = %d\n", cur_index);
	
	if((stringCmp(".", dst_path, stringLen(".")) | stringCmp("..", dst_path, stringLen(".."))) != 0) {
		stringCpy(dst_path,temp_path+cur_index, stringLen(dst_path));
		int l = stringLen(dst_path);
		if(temp_path[0] != '/' && temp_path[0] != '.'){
			for(i = l; i; i--)
				temp_path[i] = temp_path[i - 1];
			temp_path[0] = '/';
			temp_path[l + 1] = '\0';
		}
	}

	//printf("temp_path = %s\n", temp_path);
	//printf("dst_path = %s\n", dst_path);
	//printf("%d %d\n", stringCmp(".", dst_path, stringLen(".")), stringCmp( "/.", dst_path, stringLen("/.")) );
	//printf("%d\n", stringCmp(".", dst_path, stringLen(".")) & stringCmp( "/.", dst_path, stringLen("/."))) ;
	if(!(stringCmp(".", dst_path, stringLen(".")) & stringCmp( "/.", dst_path, stringLen("/.")) )) {
		if(((dst_path[0] ==  '.' && stringLen(dst_path) == 1) || (dst_path[0] == '/' && stringLen(dst_path) == 2)))
			return 0;
	}
    else if(stringCmp(dst_path, "..", stringLen("..")) & stringCmp(dst_path, "/..", stringLen("/.."))){
		ret = open(temp_path, O_READ | O_DIRECTORY);
		close(ret);
	}
    if(ret == -1) {
		ret = open(temp_path, O_READ);
		if(ret == -1) {
			printf("bash: cd: %s: No such file or directory\n", temp_path);
			return -1;
		}
		else {
			close(ret);
			printf("bash: cd: %s: Not a directory\n", temp_path);
			return -1;
		}
    }
    else {
        if((stringCmp("/..",dst_path,stringLen("/..")) &stringCmp("..",dst_path,stringLen("..")) )==0) {
			//printf("return to upper level dir\n");
            int length;
            int size=0;
            length = stringLen(cur_path);
            if (cur_path[length - 1] == '/') 
            {
                //cond = 1;
                //*((char*)cur_path + length - 1) = 0;
            }
            ret = stringChrR(cur_path, '/', &size);
            //printf("%d    %s\n",size,cur_path);
            if (ret == -1) {
                return -1;
            }
            if(size!=0) {
                *((char*)temp_path + size ) = 0;
				//printf("temp_path = %s, size = %d\n", temp_path, size);
				//printf("temp_path = %s\n", temp_path);
                stringCpy(temp_path,cur_path,size);
                //printf("%d %s\n",stringLen(cur_path),cur_path);
            }
            else
                stringCpy("/",cur_path,stringLen("/"));         
        }
        else {
            stringCpy(temp_path,cur_path,128);
            return 1;
        }     
        return 1;
    }
}

int pwd(char* cur_path) {
	printf("%s\n", cur_path);
	return 1;
}

int rm(char* cur_path, char* order){
	char  dst_path[1024];
	int length = stringLen(order);
	int size = 0;
	int ret;
	stringChrR(order, ' ', &size);
	stringCpy(cur_path,dst_path,stringLen(cur_path)); 
    stringCpy(order+size+1,dst_path+stringLen(cur_path),length-size-1);
	//printf("rm: %s\n", dst_path);
    ret = remove(dst_path);
	if(ret == -1){
		ret = remove(order + size + 1);
		if(ret == -1)
			printf("rm: cannot remove \'%s\': No such file or directory\n");
	}
    return 1;
}

int touch(char* cur_path, char* order){
	char dst_path[1024];
	int length = stringLen(order);
	int size = 0;
	int ret;
	stringChrR(order, ' ', &size);
	stringCpy(cur_path,dst_path,stringLen(cur_path)); 
    stringCpy(order+size+1,dst_path+stringLen(cur_path),length-size-1);
	ret = open(dst_path, O_WRITE | O_READ | O_CREATE);
	if(ret == -1){
		ret = open(order + size + 1, O_WRITE | O_READ | O_CREATE);
		if(ret == -1){
			printf("touch : cannot create file \'%s\'\n", dst_path);
			return -1;
		}
	}
	return 0;
}

int mkdir(char* cur_path, char* order){
	char dst_path[1024];
	int length = stringLen(order);
	int size = 0;
	int ret;
	stringChrR(order, ' ', &size);
	stringCpy(cur_path,dst_path,stringLen(cur_path)); 
    stringCpy(order+size+1,dst_path+stringLen(cur_path),length-size-1);
	ret = open(dst_path, O_WRITE | O_READ | O_CREATE | O_DIRECTORY);
	if(ret == -1){
		ret = open(order + size + 1, O_WRITE | O_READ | O_CREATE | O_DIRECTORY);
		if(ret == -1){
			printf("touch : cannot create file \'%s\'\n", dst_path);
			return -1;
		}
	}
	return 0;
}


int uEntry(void) {
	int fd = 0;
	int i = 0;
	char tmp = 0;
	
	ls("/");
	ls("/boot/");
	ls("/dev/");
	ls("/usr/");

	printf("create /usr/test and write alphabets to it\n");
	fd = open("/usr/test", O_WRITE | O_READ | O_CREATE);
	for (i = 0; i < 26; i ++) {
		tmp = (char)(i % 26 + 'A');
		write(fd, (uint8_t*)&tmp, 1);
	}
	close(fd);
	ls("/usr/");
	cat("/usr/test");
	printf("\n");
	printf("rm /usr/test\n");
	remove("/usr/test");
	ls("/usr/");
	printf("rmdir /usr/\n");
	remove("/usr/");
	ls("/");
	printf("create /usr/\n");
	fd = open("/usr/", O_CREATE | O_DIRECTORY);
	close(fd);
	ls("/");


	//next is shell
	printf("next is the display of shell\n");
	char order [1024];
	char cur_path[1024];
	stringCpy("/", cur_path, 1024);
	while(1){
		printf("%s> ", cur_path);
		char c = 0;
		int i = 0;
		scanf("%c", &c);
		while(c != '\n'){
			printf("%c", c);
			order[i++] = c;
			scanf("%c", &c);
		}
		order[i] = '\0';
		printf("\n");
		if(stringCmp("ls", order, stringLen("ls")) == 0){
			ls(cur_path);
		}
		else if(stringCmp("cat", order, stringLen("cat")) == 0){
			char destFile[1024];
			int i = 0;
			for(i = 0; i < stringLen(order); i++){
				if(order[i] == ' ') break;
			}
			stringCpy(order + i + 1, destFile, stringLen(order) - i);
			//printf("shell_cat: order = %s, destFile = %s\n", order, destFile);
			shell_cat(cur_path, destFile);
		}
		else if(stringCmp("cd", order, stringLen("cd")) == 0)
			cd(cur_path, order);
		else if (stringCmp("pwd", order, stringLen("pwd")) == 0)
			pwd(cur_path);
		else if(stringCmp("rm", order, stringLen("rm")) == 0)
			rm(cur_path, order);
		else if(stringCmp("touch", order, stringLen("touch")) == 0)
			touch(cur_path, order);
		else if(stringCmp("mkdir", order, stringLen("mkdir")) == 0)
			mkdir(cur_path, order);
		else if(stringCmp("exit", order, stringLen("exit")) == 0)
			break;
		else {
			printf("%s: command not found\n", order);
		}
	}
	
	exit();
	return 0;
}
